# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['flask_security']

package_data = \
{'': ['*'],
 'flask_security': ['templates/security/*',
                    'templates/security/email/*',
                    'translations/*',
                    'translations/da_DK/LC_MESSAGES/*',
                    'translations/de_DE/LC_MESSAGES/*',
                    'translations/es_ES/LC_MESSAGES/*',
                    'translations/fr_FR/LC_MESSAGES/*',
                    'translations/ja_JP/LC_MESSAGES/*',
                    'translations/nl_NL/LC_MESSAGES/*',
                    'translations/pt_BR/LC_MESSAGES/*',
                    'translations/pt_PT/LC_MESSAGES/*',
                    'translations/ru_RU/LC_MESSAGES/*',
                    'translations/zh_Hans_CN/LC_MESSAGES/*']}

install_requires = \
['Flask-BabelEx>=0.9.3',
 'Flask-Login>=0.4.1',
 'Flask-Mail>=0.9.1',
 'Flask-Principal>=0.4.0',
 'Flask-WTF>=0.14.2',
 'Flask>=1.0.2',
 'itsdangerous>=1.1.0',
 'onetimepass>=1.0.1',
 'passlib>=1.7',
 'pyqrcode>=1.2']

setup_kwargs = {
    'name': 'flask-security',
    'version': '3.0.1',
    'description': ' Flask-Security is an opinionated Flask extension which adds basic\n  security and authentication features to your Flask apps quickly\n  and easily',
    'long_description': None,
    'author': 'Matt Wright',
    'author_email': 'matt@nobien.net',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.5',
}


setup(**setup_kwargs)
